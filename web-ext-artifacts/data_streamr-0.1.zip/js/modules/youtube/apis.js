console.log("modules/youtube/apis.js");
import {Youtube} from './manifest.js';
Youtube.apiCall = [
	{
		name: "recentActivities",
		description: "",
        title: "User recent activities",
        is_enabled: true,
		method: "GET",
		URI: "/activities/",
        bearer: true,
		content_type: "application/x-www-form-urlencoded",
        permissions: [],
		params:{
			mine: true,
            maxResults: 50,
            part: "snippet,contentDetails"
		},
		response_type: "json",
		verifyResponse(response) {
			return new Promise((resolve, reject) => {
				if (response.status != 200) {
					reject("Token validation error");
				}
				response.json().then((json) => {					
					resolve(json);
				});
			});
		}
	},
    {
		name: "myChannels",
		description: "",
        title: "User channels",
        is_enabled: true,        
		method: "GET",
		URI: "/channels/",
        bearer: true,
		content_type: "application/x-www-form-urlencoded",
        permissions: ["https://www.googleapis.com/auth/youtubepartner-channel-audit"],
		params:{
			mine: true,
            part: "snippet,contentDetails,statistics"
		},
		response_type: "json",
		verifyResponse(response) {
			return new Promise((resolve, reject) => {
				if (response.status != 200) {
					reject("Token validation error");
				}
				response.json().then((json) => {					
					resolve(json);
				});
			});
		}
	},
    {
		name: "channelsManagedByMe",
		description: "",
        title: "channel managed by User",
        is_enabled: true,        
		method: "GET",
		URI: "/channels/",
        bearer: true,
		content_type: "application/x-www-form-urlencoded",
        permissions: ["https://www.googleapis.com/auth/youtubepartner-channel-audit"],
		params:{
			managedByMe: true,
            part: "snippet,contentDetails,statistics"
		},
		response_type: "json",
		verifyResponse(response) {
			return new Promise((resolve, reject) => {
				if (response.status != 200) {
					reject("Token validation error");
				}
				response.json().then((json) => {					
					resolve(json);
				});
			});
		}
	},
    {
		name: "channelSections",
		description: "",
		method: "GET",
        title: "Channel sections",
        is_enabled: true,        
		URI: "/channelSections/",
        bearer: true,
		content_type: "application/x-www-form-urlencoded",
        permissions: [],
		params:{
			mine: true,
            part: "snippet,contentDetails"
		},
		response_type: "json",
		verifyResponse(response) {
			return new Promise((resolve, reject) => {
				if (response.status != 200) {
					reject("Token validation error");
				}
				response.json().then((json) => {					
					resolve(json);
				});
			});
		}
	},
    {
		name: "myPlaylists",
		description: "",
        title: "User playlist",
        is_enabled: true,        
		method: "GET",
		URI: "/playlists/",
        bearer: true,
		content_type: "application/x-www-form-urlencoded",
        permissions: [],
		params:{
			mine: true,
            part: "snippet,contentDetails"
		},
		response_type: "json",
		verifyResponse(response) {
			return new Promise((resolve, reject) => {
				if (response.status != 200) {
					reject("Token validation error");
				}
				response.json().then((json) => {					
					resolve(json);
				});
			});
		}
	},
    {
		name: "mySubscriptions",
		description: "",
        title: "User subscriptions",
        is_enabled: true,        
		method: "GET",
		URI: "/subscriptions/",
        bearer: true,
		content_type: "application/x-www-form-urlencoded",
        permissions: [],
		params:{
			mine: true,
            part: "snippet,contentDetails"
		},
		response_type: "json",
		verifyResponse(response) {
			return new Promise((resolve, reject) => {
				if (response.status != 200) {
					reject("Token validation error");
				}
				response.json().then((json) => {					
					resolve(json);
				});
			});
		}
	},
    {
		name: "myLikedVideos",
		description: "",
        title: "User linked videos",
        is_enabled: true,        
		method: "GET",
		URI: "/videos/",
        bearer: true,
		content_type: "application/x-www-form-urlencoded",
        permissions: [],
		params:{
			myRating: "like",
            part: "snippet,contentDetails,statistics"
		},
		response_type: "json",
		verifyResponse(response) {
			return new Promise((resolve, reject) => {
				if (response.status != 200) {
					reject("Token validation error");
				}
				response.json().then((json) => {					
					resolve(json);
				});
			});
		}
	}
];

/*

function gBatchCall(apiInfoList)
{
	let gettingItem = retrieveData(config.name);
	gettingItem.then(item => {
		access_token = item[config.name].tokenInfo.token;
		endpoint = config.apiConfig.api_endpoint;
		var batch = [];
		for(apiInfo of apiInfoList)
		{
			switch(apiInfo.method)
			{
				case "GET":
					item = {
						method: apiInfo.method,
						relative_url: apiInfo.URI.concat("?", serialize(apiInfo.params))			
					}	
					break;
				case "POST":    
					item = {
						method: apiInfo.method,
						relative_url: apiInfo.URI,
						body: serialize(apiInfo.params)
					}
					break;
				default:
			}
			batch.push(item);			
		}
		aInfo = {
			method: "POST",
			URI: "/",
			content_type: "application/x-www-form-urlencoded",
			params: {
				batch: JSON.stringify(batch)
			}
		}
		apiCall(endpoint, aInfo, access_token).then(verifyBatchResponse).then(resp => console.log(resp));				
	})	
}

function verifyBatchResponse(response) {
	return new Promise((resolve, reject) => {
		if (response.status != 200) {
			reject("Token validation error");
		}
		response.json().then((json) => {				
			resolve(json);
		});
	});	
}
*/