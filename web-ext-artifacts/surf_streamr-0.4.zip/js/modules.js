console.log("modules.js");
var AllModules = (function() {
        return [];
}());
export {AllModules};