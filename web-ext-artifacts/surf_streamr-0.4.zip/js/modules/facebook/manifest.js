console.log("modules/facebook/manifest.js");
import {AllModules} from '../../modules.js';
var Facebook = (function() {
    'use strict';
    
    return {
        name: "facebook",
        description: "This module look through all the user activities on facebook and capture those activities that user have permitted",
        path: "/facebook",
        URL: ["https://www.facebook.com"],
		viewGroups: [
			{
				name: "UX",
				title: "User Experience"
			},
			{
				name: "API",
				title: "Facebook API"
			}
		],
        functions: ["browsing", "apiCall"],
        is_enabled: true,
        privacy_level: 3,
        status: "enabled",
        icons: ["data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEwAACxMBAJqcGAAADchJREFUeJzt3X1wVfWZB/Dv89ybBEIIRvCNxkDqOwulDhUdQNmQV1osOi1Qu27zci+huzMuY1ntjKyNqQPTVdYZ6z8lJLkROmM1jLotDqncgLTQIg6z09WqVSkQBlZNITVvmNx7n2f/yIuJ3CT35bzd5Hz+y805v98XzpNzz8vv/A5hkqmpqeEjbXnzPcCCiGg+AflElCfAVUSYTZDZAmQykC7C6QDALP0C9DPQq+ALqrjAQLsSzqjoaQ/TqQjw7oq8ttO1tbVi97/RSGR3gGSV+etyJexdrqTLAdwhkEUMnmFKZ4JuEN5W6FsgOioRz9GDuyvOmdKXRVKuAFaWB6alsxSoahmRrgb4JpsjfQBgvyrt987seqPluc19NueJS0oUwJLqnWmzQ97SiOgGAq0lxky7M0UjkE5WvKrwvNiRHjpwom5TyO5ME3F0ARRVNN4EiF8JFQy62u488ZGPodQUFm/9od0VJ+1OMxYHFoBScUWgACRbAPqm3WkMoXhNVHa0Pu8/DJDaHWckBxWAUkl5w1ol+gkIt9udxgwCnGCV2gNN/n1OKQRHFEBRRWOpkm5jYIndWaygiuNK2Noa8AXtzmJrAZSUB24VCj9DxKvtzGEXFd2nIlta91R/YFcGWwpgTfXOzM/7vU+Q4mEwvHZkcAxBSBk7uruynjy2d8Mlq7u3vACKKxpXgaQOoBus7tvZ5EMFbwwGfIet7NWyAlhZHpiWRpH/JKJ/s6rPVKTAM96s7sesuqBkSQEUV9UvlAi9wIyFVvSX6kTkT+TFA8GGje+Z3Reb3UFRZcMDEqE33Y0fO2ZerIK3iisbvmt2X6btAdate8nTkdn5NDE9bFYfU4GqPpXTk/1Yc/P6iBntm1IAxQ/uniFpoRcYuNeM9s3ATMi9ZhZyr83GlbMykTNrOrIy05Ge5kFamgceZlAC/1vNLW/jZNvFpLKJyivT0+XBfXWbepNqKArDC2CVb9c1JPya0y/qMBO+dsu1WPIPX8HtC+YiPzcHaV6P4f08/uwBvPmns0m3o4rjXsKaloCv3YBYwww9By/z1+WGQxwkxi1GtmukOTmZWFu4AMXLb8SVszLtjhMzIiyNiLxRVFVfHGz0nzeqXcMKoLQ8MD8UloPMyDeqTSNNz0jDP993O7696jakpxn/l24J5gWk+ruCqvrCQ43+M4Y0aUQjZf663DDJQSZnbvwFN1yNX/z0Pny3dGHqbvxhdINX0VpUVT/XiNaSLoBVvl3XhEOeoFM3/t1L5uPpH6/GdVc5cgxJgugGEgqWVTZclWxLSRVA8YO7Z5Dwa079zr9z8fXY+i8Fphzc2Y5wW0jkN2uqdyZ1IJNwAaxb95Jn8FTPkUf78+Zega0/LACzI+54m4KZ77zUz79ct+6lhCs84QLoyOp6yqnn+USEf/fdjWkZk/9GIxPf3zGjc3vC6yeyUlFlwwME/CjRTs1WsuIm3JKf9NdjyiCiRwur6r+TyLpxF0BxVf1CFdQn0pkVmAkPfGux3TEsxxFqKikP3Br3evEsvLI8MG3wrp5jr6B8Y+FXMPfqyXTEHyNGVoQjL5Q99GxGfKvFIZ3lZ06/q7fqrqk7zoRBX490zdgW3zoxKq5oXAVgc9ypLEQE3LEo1+4Y9iLaUlxVf0+si8dUAGuqd2YODONytvzcKzFzRlx7wMlJadfK8sC0WBaNqQA+7/fUpMIYvpvnz7E7glPcnE6R/4hlwQlPlEvKA7eqyo+c8QTB+ObNvcLU9kUUp8914Nwnnejs/hyhsEB1/Oc7Pm7vMjXTmJQeLfHtanq9YeNH4y02YQEMjttPiSsq15p0vf9SXwh7Xv0ftBz5EN09KfLwLyNNhXYAuG/8xcZRVNFYmkoPbeRkTze8zXBY8OOnW7D3t++kzsYfRmsHD97HNE4BKClpXKcUdsvOMv4A8PWjH+L9vxo6CMdapNsAHfMLfMwCKClvWOvUGz1jyUg3/pvqmAHDuWx2V1FFYMy9+BgFoKREPzErkVnMuO177pPPDG/Teloz1l4gagEMPJ+feo9om3Hrt/eS4yf5mBARlpZWBFZE+130PQDJFlMTpZCJTvNSRZj0kWifX1YAJb5dN06amTlcwxi4t7Cy4atRPh9Nhf3WRHJZjQFflM++sKR6Z5pAK62L5LKSKCpX1tSMOlUaVQCzQ97S1JuNyxUrJlznPZ1bNOqzkT8osN7aSC6rMWj96J8HrSwPTFMZ/7qxaxJgvX/kqKHhAkhnKXDqDJwuI/EV0pU5PGBkuABUtcyeQC6rCfHwth4+IhyYeNlZN/1nzshA7rWzYl7e4zE+/43zZqOrpz/h9dvO/x09lxJf3wykWA1gCzC4xcv8dbmRiMdxdz3u/sZ8PP6v497NdLyHnvwN/nLKeXcT2Rua+9tdP/w/BgAJe5fbHWiyar/YbXeEqMIR7zJg8Bhg8GULLoOFwhF0dFo+92NMKILlwBcHgXfYmGXSar/YC6feS1KmpQDANTU1LJBFdgeajD694Mzd/wBZBCh5j7TlzWfAnHfsTHGfOvT7HwAYnF1Q1ZDHHmCB3WEmq08v9NgdYVxepQUcEXXk1C6TgbO/AgCo5jPBmXP7TAafXnT2HgBE+UxEeXbnmKwcvwcA5rEAU2cqDYs59SLQEFXMYSLMtjvIZPRZ9+fo6zdlfmfDEMkcJohbACZod/gZAACI8hwWOHe6l1SWAt//YJLpzEC63UEmI8efAQzI4KFXqLuMlQp7ABHOoMLyhgiz+a+OscLen/+T4U8If+/hF3DxM2fe0UuWCISZxVnDVVyWYZY+FsAtgKmrjxkw/D00rhQh3MsKvmB3DpdNWC6wKtwCmKJU+W/MgPOGrLosQZB2VoIhLx9ypR4Fn2EVPW13EJc9lHCKPUyn7A7isgcDpzkCvGt3EJc9NBz+M6/IazsNgfMvXLuMJfgsuKf6LNfW1goIb9udx2UtYbwDkA48GgZ9y+5ALmuR6HFg6NEwoqO2pnFZj/QIMFgAEvG4BTDFhNT7B2CwAA7urjgH4ANbE7msI/Lu4ecrPwZGzxK236Y4LqsRDW/rEXMEkVsAU4QqLi8A78yuNwTSaU8kl1UE6Mjpzf790M/DBdDy3OY+VrxqTyyXVQh4pbl5/fAosC/NFOp50fpILisR6ahtPKoAOtJDByD4xNpILssIzvdff/bgyI9GFcCJuk0hkAasTeWyDGngcG1teORHlz0PEBavY18N70qGKLzS8OVPLyuAQ7srTkLxmjWhXNahXx+or75s7EfUJ4JEZYf5gVxWUlDUbRq1AFqf9x8W4IS5kVwWOhYMVEW93zPGM4GkrFJrZiKXdVTpCYCiTlk55kOhB5r8+1Rx3LRULksIcDTYVPn6WL8f56lgUiVsNSOUyzoEbB3rrx+Y4O3hrQFfUEX3GR/LZZGXgwHf4fEWmHBeABXZAkHqvz91ihFIvwBR3xY60oQF0Lqn+gNluKeFKYaVftYa8P11wuViaay7K+tJQD5MPpbLCgJ93zOzZ3ssy8ZUAMf2brik4I3JxXJZQ5RAG1ue29wXy9Ixzw0UDPgOK/BM4sFcVlClp4MB35FYl49rcihvVvdjAP437lQuSwhwIqcn+/F41omrAFqe29ynLN8TSEpMgjeVCKQT4cj3R472iUXc08MFGza+x0ruG8adRj0/aN1THffQ/oTmBzzQ5G9W1acSWddliu2tTVX/nciKCU8QmdOT/ZiovJLo+i7DNC/La4vre3+khAuguXl9ZHq6PAj3wVL7KP7Y1ZVVXltbK4k2kdQUsfvqNvV6QN+C4r1k2nHFTwTvSMR777G9G5KaxzbpOYJbAr52ZS2CyISXHV3GEMFHYXBx657ypKf4M2SS6GCj/3zYQ6sAPWlEe66xieAjknDh0MOdyTJslvBDjf4zSrjH/TowjwjeCYPvDu7Z1GZUm4ZOEx9s9J/3EFa6I4lMoPgjxPuPRv3lD/Ea2RgwcEywpnpnwaV+/iUT3290++M59OZJZE5LM7RNh7z4qbmrO6s82QO+aMjoBoesW/eSp2NG53YietSsPqaI7cvy2h5P5lRvPKYVwJDCqvrvcISawMgyu6/JRCCdUM8PEr3CFyvTCwAASsoDt0YQ/hUzL7aiv1QnwAmEI99P5Np+vCx5V9Drz1e+n5bdeydU/8uK/lKXqKo+dWX3zGVWbHzAoj3ASMVV9fdAaReAm63u28kE+j6BNsYzmMMIlr8t7ECj/3f9wouhus0dbTwweheqP03L6vm61RsfsGEPMFKJb9eNKrQDoLV25rDRywI8EsvoXbPYWgBDiisaV4F0G4C77M5iBQGOErB1ooc2rOCIAhigVFQRWA1oDRGW2p3GJMdU6YmBZ/XGflzLSg4qgCFKpRWBFWHSRxi41+40yRMF6NcK2jHwiLYzNvwQBxbAFworG77KgE8UlUy4zu48cRGcV0YjeSKN0WbmcApHF8CQJdU7067o40IQb2DF/WDMsjtTdPJ3Bb9MpC/2X3/24JcnZHKilCiAkcoeejZDujLvEeIyUqwG4TZbA4m8C6L9qtif05v9+3iHZdst5Qrgy0o3/uK6cMS7jCJYrkxLAVnE4Gwz+hqYSpffJtHjID0SUu8fjL49a7WUL4DLKRVUNeR5lRZANR9E+QDmqWIOkcwR5TlMMh1AhghnAANv0QbQB+FesFxQ5b8RpF3BZ5RwioHTGg7/Obin+qzTDuKS9f9C1LZrvPgyGAAAAABJRU5ErkJggg==","",""],
        version: 1,
        changelog: [],
		style: {mainColor:"29487D", fontColor:"fff"},
		type: "builtin",
		is_verified: false		
    };
}());
AllModules.push(Facebook);
export {Facebook};