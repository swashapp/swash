var streamrConf = {
	STREAM_ID: '************************',
	API_KEY:'**********************************'
}
export {streamrConf};