var streamrConf = {
	STREAM_ID: 'jfAEw9hIS1GHJosAgNGNLw',
	API_KEY: '2xkxcNPFQte-ztpVtDfB7QTYBckeD0QhCA1ZnBjSEDRg',
    PUSH_STREAM_ID: "UUSJ4StCQHKOKvYzCgZ-hw",
    PUSH_API_KEY: "QageytBgRGG5DFRdFA47hQ9sjWw-YjTyu7as4wR-zlEA",
    PUSH_ID: "lgknlkgnlkdgnflkgnoevneo"
}
export {streamrConf};